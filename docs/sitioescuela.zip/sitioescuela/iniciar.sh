#! /bin/bash
x-terminal-emulator -e "./venv_init.sh" &

